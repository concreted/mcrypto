# Matasano Crypto
# 2-14

from mclib import *

#find_appended(consistent_encryption_oracle)
find_appended_random(inconsistent_encryption_oracle)