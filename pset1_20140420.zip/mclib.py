import sys
import binascii as ba

# hexToBase64(string s)
# Convert hex string to base 64 without leading/trailing whitespace.
def hexToBase64(s):
	return ba.b2a_base64(ba.unhexlify(s)).strip()
	
def Base64ToHex(s):
	return ba.hexlify(ba.a2b_base64(s)).strip()
	
# ASCIIToBinary(string s)
# Convert ASCII string to binary (left-padded to 8 digits).
def ASCIIToBinary(s):
	return "".join([(bin(ord(c))[2:]).zfill(8) for c in s])
	
# XOR(string x, string y)
# XOR two equal-length hex strings together.
def XOR(x, y):
	assert len(x) == len(y)
	
	x = ba.unhexlify(x)
	y = ba.unhexlify(y)
	
	return ba.hexlify(bytearray([ord(a) ^ ord(b) for a, b in zip(x, y)]))
	
# XOR_ASCII(string x, string y)
# XOR two ASCII strings together.
def XOR_ASCII(x, y):
	return XOR(ba.hexlify(x), ba.hexlify(y))
	
# XOR_SingleChar(string ciphertext, int charascii_dec)
# XOR a hex string with a single char (ASCII decimal value)
def XOR_SingleChar(ciphertext, charascii_dec):
	singleChar = '%02x' % charascii_dec
	cipher = singleChar * (len(ciphertext)/2)
	
	return ba.unhexlify(XOR(cipher, ciphertext))
	
# XOR_RepeatingKey(string plaintext, string key)
# XOR an ASCII string plaintext with a short ASCII key.
# repeating the key to match length of plaintext.
def XOR_RepeatingKey(plaintext, key):
	size = len(plaintext)
	keysize = len(key)
	cipher = (key * (size/keysize)) + key[:size%keysize]
	
	return XOR_ASCII(plaintext, cipher)

# find_XOR_SingleChar(string ciphertext)
# XOR ciphertext with all 128 normal ASCII chars, 
# to find result most likely to be plain English.
# Return best candidate ASCII char, and XOR result.
def find_XOR_SingleChar(ciphertext):
	best = 0
	score = 0
	bestResult = ""
	
	for i in range(128):
		result = XOR_SingleChar(ciphertext, i)
		metric = alphaMetric(result)

		if metric > score:
			best = i
			score = metric
			bestResult = result
			
	return chr(best), bestResult
	
# hammingDistance(string a, string b)
# Calculate bitwise Hamming Distance of two ASCII strings.
def hammingDistance(a, b):
	size_a = len(a)
	size_b = len(b)
	
	if size_a < size_b:
		a = a + (" " * (size_b - size_a))
	elif size_b < size_a:
		b = b + (" " * (size_a - size_b))
	
	a = ASCIIToBinary(a)
	b = ASCIIToBinary(b)

	return sum(x != y for x, y in zip(a,b))
	
# alphaMetric(string plaintext)
# Calculate metric (between 0 and 1) of how likely given plaintext is 
# normal English text.
def alphaMetric(plaintext):
	score = 0.0
	plaintext_size = len(plaintext)
	plaintext_lowercase = plaintext.lower()
	
	for i in range(0, plaintext_size): 
		char_ascii_val = ord(plaintext_lowercase[i])
		
		if (char_ascii_val >= 97 and char_ascii_val <= 122) or (char_ascii_val == 32):
			score = score + 1.0
		
	return score/plaintext_size
	
# listMatchCount(any item, list l)
# Return number of occurrences of item in list l.
def listMatchCount(item, l):
	return sum(x == item for x in l)
	
# detectECB(string ciphertext):
# Detect ECB encryption in given ciphertext. Return True or False.
def detectECB(ciphertext):
	n = 16
	size = len(ciphertext)
	blocks = [ciphertext[i:i+n] for i in range(0, size, n)]
	duplicates = max(listMatchCount(x, blocks) for x in blocks)
	if duplicates > 2:
		print "ECB detected - max %i duplicates\n" % duplicates
		print ciphertext
		print blocks
		return True
	return False
	
def test():
	print hammingDistance("this is a test", "wokka wokka!!!")
	print Base64ToHex('AAAA')
