# Matasano Crypto
# 1-7

from mclib import *

from Crypto.Cipher import AES
from Crypto import Random

f = open("gistfile1_1-7.txt")

buffer = ba.unhexlify(Base64ToHex("".join([line.strip() for line in f])))

key = b"YELLOW SUBMARINE"
iv = Random.new().read(AES.block_size)
cipher = AES.new(key, AES.MODE_ECB, iv)
msg = cipher.decrypt(buffer)
print msg