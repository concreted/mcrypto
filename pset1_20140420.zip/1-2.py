# Matasano Crypto
# 1-2

from mclib import *

x = "1c0111001f010100061a024b53535009181c"
y = "686974207468652062756c6c277320657965"

z = XOR(x,y)

print z

assert "746865206b696420646f6e277420706c6179" == z
	