# Matasano Crypto
# 1-4

from mclib import *

f = open("gistfile1_1-4.txt")

score = 0
best = ""
ctext = ""

for line in f: 
	result = find_XOR_SingleChar(line.strip())[1]
	metric = alphaMetric(result)
	if metric > score:
		score = metric
		best = result
		ctext = line

print ctext
print best
	
	